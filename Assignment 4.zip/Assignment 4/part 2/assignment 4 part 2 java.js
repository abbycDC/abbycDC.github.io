﻿/*
  Name: Abby c
  Course: INFT1206
  Assignment: Assignment 4 - Part 2: Interactive Skills Dashboard
  Date: 2026-04-03
  Description: JavaScript adds dynamic interactions to the skills dashboard (scroll animation, card flip, level booster).
  this is when brocode camein handy. part 1 of this assignment has his youtube videos as referance.
*/

document.addEventListener('DOMContentLoaded', function () {
  const cards = document.querySelectorAll('.skill-card');

  // Function to animate a card's progress bar to its data-percentage
  function applyProgress(card) {
    const targetPercent = Math.min(Number(card.dataset.percentage), 100);
    const fill = card.querySelector('.progress-fill');
    const label = card.querySelector('.progress-value');
    const progressBar = card.querySelector('.progress-bar');

    fill.style.width = `${targetPercent}%`;
    label.textContent = targetPercent;
    progressBar.setAttribute('aria-valuenow', targetPercent);
  }

  // IntersectionObserver triggers progress fill when card is in viewport
  const observer = new IntersectionObserver(
    (entries, observerRef) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          applyProgress(entry.target);
          observerRef.unobserve(entry.target);
        }
      });
    },
    {
      root: null,
      threshold: 0.4,
    }
  );

  // Add event listeners to flip and increase buttons for each card
  cards.forEach((card) => {
    observer.observe(card);

    const flipBtn = card.querySelector('.flip-btn');
    const increaseBtn = card.querySelector('.increase-btn');

    flipBtn.addEventListener('click', () => {
      card.classList.toggle('flipped');
    });

    // Additional interactive feature: increase skill by 5% on click
    increaseBtn.addEventListener('click', () => {
      let current = Number(card.dataset.percentage);
      current = Math.min(current + 5, 100);
      card.dataset.percentage = current;
      applyProgress(card);

      // small highlight effect to provide immediate feedback
      card.classList.add('recent-update');
      setTimeout(() => card.classList.remove('recent-update'), 300);
    });

    const decreaseBtn = card.querySelector('.decrease-btn');
    decreaseBtn.addEventListener('click', () => {
      let current = Number(card.dataset.percentage);
      current = Math.max(current - 5, 0);
      card.dataset.percentage = current;
      applyProgress(card);

      card.classList.add('recent-update');
      setTimeout(() => card.classList.remove('recent-update'), 300);
    });

    // Optional: close flip if card is clicked while flipped
    card.addEventListener('click', (event) => {
      if (!event.target.classList.contains('flip-btn')) {
        if (card.classList.contains('flipped')) {
          card.classList.remove('flipped');
        }
      }
    });
  });

  // Scroll-to-view progress on initial page load for visible cards
  cards.forEach((card) => {
    const rect = card.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom >= 0) {
      applyProgress(card);
      observer.unobserve(card);
    }
  });
});
