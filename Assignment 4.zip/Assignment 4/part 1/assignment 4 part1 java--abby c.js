/*
	Name: Abby C
	Course: INFT1206
	Assignment: Assignment 4 - Part 1: Interactive Resume
	Date: 03-04-2026
	Description: JS interactivity for resume page (animations, events, and all that jazz).
    This is mainly where I used BroCode-- he explains how code works and why we put it in its way in simple and easy tounderstand ways.
*/

//Loading animation control (fade out after page load)
const loadingScreen = document.getElementById('loadingScreen');
const pageContent = document.getElementById('pageContent');

window.addEventListener('load', () => {
	setTimeout(() => {
		loadingScreen.classList.add('hide');
		pageContent.setAttribute('aria-hidden', 'false');
	}, 1300);
});

//Title click bounce effect
const heroName = document.getElementById('heroName');
heroName.addEventListener('click', () => {
	heroName.classList.add('active');
	setTimeout(() => heroName.classList.remove('active'), 500);
});

//Button toggles summary animation state
const aboutToggle = document.getElementById('aboutToggle');
const aboutSection = document.getElementById('aboutSection');
aboutToggle.addEventListener('click', () => {
	aboutSection.classList.toggle('animate-slide-in');
	aboutSection.classList.toggle('visible');
	if (aboutSection.classList.contains('visible')) {
		aboutToggle.textContent = 'Reset summary animation';
	} else {
		aboutToggle.textContent = 'Toggle summary animation';
	}
});

//Scroll reveal animation for cards and sections
const revealItems = document.querySelectorAll('.cards .card, .info-section, .contact-panel');

function revealOnScroll() {
	const revealPoint = window.innerHeight * 0.84;
	revealItems.forEach((item) => {
		const itemTop = item.getBoundingClientRect().top;
		if (itemTop < revealPoint) {
			item.classList.add('visible');
		}
	});
}

window.addEventListener('scroll', revealOnScroll);
window.addEventListener('load', revealOnScroll);

//Custom cursor spotlight and follow motion
const body = document.body;

body.addEventListener('mousemove', (e) => {
	const x = e.clientX;
	const y = e.clientY;
	body.style.setProperty('--mouse-x', `${x}px`);
	body.style.setProperty('--mouse-y', `${y}px`);
});

// This effect uses CSS variables--go to CSS for .hero

//Data note for accessibility and validation interaction
const githubIcon = document.getElementById('githubIcon');
if (githubIcon) {
	githubIcon.addEventListener('mouseenter', () => {
		githubIcon.setAttribute('aria-label', 'Go to GitHub profile');
	});
}

//Keyboard accessible animate skill pills
const skillPills = document.querySelectorAll('.skill-pill');
skillPills.forEach((pill) => {
	pill.setAttribute('tabindex', '0');
	pill.addEventListener('focus', () => {
		pill.style.transform = 'scale(1.05)';
	});
	pill.addEventListener('blur', () => {
		pill.style.transform = 'scale(1)';
	});
});
